public  class superClass {

    //Yöntemler bu kodda statik değildir.
     public  void islem(){
        System.out.println("superclass islemi ");
    }
}
