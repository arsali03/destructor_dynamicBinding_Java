/*Ali Arslan
  1210505017

  Dinamik Binding Nedir?*/


public class Main {
    public static void main(String[] args) {
        superClass srClass = new superClass();
        superClass sbClass = new subClass();

        /*Derleme sırasında, derleyici nesne türüne göre değil
         yalnızca değişkene başvurarak gittiğinden ve bu nedenle
         bağlama çalışma zamanına erteleneceğinden ve bu nedenle baskının
         karşılık gelen sürümü olacağından, derleyicinin hangi baskının
         çağrılması gerektiği konusunda hiçbir fikri yoktur ve nesnenin
         tipine göre çağrılır.*/

        srClass.islem();
        sbClass.islem();

    }
}