/*Ali Arslan
  1210505017

  Destructor Nedir?

  Java dilinde bu fonksiyonlar kaldırıldığı için finalize kullandım.

    */


public class Main {
    public static void main(String[] args) {
        new class1(2);
        System.gc();

        System.out.println("--------------");

        new class1(3);
        System.gc(); //Çöp toplayıcısını çalıştırır.
        System.out.println("--------------");

        new class1(5);
        class1 a = new class1(4); //çöp toplayıcı tarafından silinmez.

        System.gc();

    }
}