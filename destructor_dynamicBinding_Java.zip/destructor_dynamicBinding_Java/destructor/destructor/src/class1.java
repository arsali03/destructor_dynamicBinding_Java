public class class1 {
    int sayi1=0;

    public class1(int sayi1){
        this.sayi1=sayi1;
        System.out.println("nesne oluşturuluyor. " + sayi1);
    }
    public void finalize(){
        System.out.println("nesne yok ediliyor.. "+sayi1);

    }

}
